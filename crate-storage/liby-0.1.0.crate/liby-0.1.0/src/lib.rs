use rand::Rng;

pub fn funy(n:i32)->i32 {
    let c = rand::thread_rng().gen_range(0..n);
    c
}
