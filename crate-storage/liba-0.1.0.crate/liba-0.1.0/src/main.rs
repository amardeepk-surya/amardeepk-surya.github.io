use rand::Rng;

pub fn main(){
    let c = rand::thread_rng().gen_range(0..5);
    println!("{}",c);
}