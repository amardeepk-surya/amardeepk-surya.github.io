use liby::funy;

pub fn funa(n:i32)->i32 {
    let c=liby::funy(n);
    c
}
