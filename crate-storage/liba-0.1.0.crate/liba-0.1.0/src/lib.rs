use rand::Rng;

fn libafn(n:i32)->i32 {
    let c = rand::thread_rng().gen_range(0..n);
    c
}
