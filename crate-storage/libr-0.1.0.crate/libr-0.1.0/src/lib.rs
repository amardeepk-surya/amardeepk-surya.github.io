use rand::Rng;

pub fn function(a:i32)->i32 {
    let num = rand::thread_rng().gen_range(0..a);
    num
}