use rand::Rng;

pub fn addr(a:i32,b:i32)->i32{
    let c= rand::thread_rng().gen_range(0..10);
    a+b+c
}
